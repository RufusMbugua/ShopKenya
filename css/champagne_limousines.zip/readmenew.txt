Champagne & Limousines TrueType� Font Family
By and � (copyright)  Lauren Thompson 
--------------------------------
Free for Personal Use
Donation required for Commercial Use 
Email nymphont@yahoo.com for details

More fonts by Lauren Thompson visit: 
http://www.nymFont.com
or
http://www.dafont.com/lauren-thompson.d1997 

=============================
Terms of Use/End User Lisence Agreement
==============================
Upon downloading this font the user bound to abide 
the Free Font Terms of Use/Free Font End User 
License Agreement (TOU/EULA) defined below. 
This agreement pertains to you/the user and the 
liscencing rights aquired with this download. These 
rights are specific to free download and usage of this 
font, i.e. a personal use License agreement.
-----------------------------------------------
Free Font Terms of Use
Free Font End User License Agreement:
-----------------------------------------------
1.) This font is free for personal use* and may not
be used commercially.** Read entire TOU/EULA for 
more information. Further comments, questions, and 
suggestions should be directed to Lauren Thompson, 
nymphont@yahoo.com. 

2.) The distribution of this font for financial gain or 
profit is not permitted under any circumstances and is 
strictly prohibited. Do not add this font to a font CD or 
compilation and or archive that is to be sold for a profit. 

Basically, don't sell this font, and do not make things 
that are to be sold with this font... It's free for personal 
use only. Commercial use requires the user to obtain a 
Commercial Font End User License. A Commercial Font
End User License is granted after a PayPal donation has
been received. Email me nymphont@yahoo.com for
more details.

For profit scrapbooking and digital scrapbooking material (s) or 
scrapbooking and digital scrapbooking material(s) intended to 
be sold/resold with this font are also prohibited under this license, 
and require a commercial License. To obtain a Commercial 
Font End User License for this font email nymphont@yahoo.com.

Please note, scrapbooking and digital scrapbooking use of this 
 font is only restricted when pertaining to the making of any for 
profit items. Otherwise creating items to be used "personally," 
whether in a traditional scrapbook or digital scrapbook is entirely 
permitted under this free License. 

3.) This font file must be kept intact as downloaded. Under no 
circumstances may this font file itself be edited, altered, or modified 
at any time or in any measure. This prohibits and indcludes but is 
not limited to, renaming this font file, as well as the creation of 
so-called "new" and/or derivitave fonts from this font file or any 
other possible digital representations.

4.) Redistribution of this font is permitted only if this readme is, as well 
as the font file itself, kept intact as is, and it is offered free of charge, 
no fee is implemented upon the aquistition of this font. If you do 
redistribute this font, please email Lauren Thompson, 
nymphont@yahoo.com with details. 

5.) Upon downloading this font, the user accepts all liability and 
sole responsibility for the font file and any accompanying files 
therein. Lauren Thompson (Nymphont) is not responsible or 
liable for any damages, loss or other consequences incurred 
as a result of downloading this font, or otherwise relating or 
associated with the download. 

*Personal use does not constitute "public domain." 

**If you are interested in the commercial use of this font or using 
this font in any manner outside the realm of "personal use," you 
must obtain the rights to use this font commercially 
(Commercial Font End User License)  prior to doing so. To obtain 
a Commercial Font End User License Agreement with this font, 
contact me Lauren Thompson, nymphont@yahoo.com. 

Thank you for accepting and abiding these terms. What can I say 
I really love to font! If you've got it, font it! 

Moving right along, have lots of fun with this font. Let me know 
what you think by dropping me a line at nymphont@yahoo.com. 
I'd love to see what you have created using my font and how 
you have put it to use.
http://www.nymfont.com/ 